const datosUrl = 'http://localhost:3000/api/total/';
const url = 'http://localhost:3000/';

//------------------------------------------------------------------------------

const navbarClick = document.getElementById('login');

navbarClick.addEventListener('click', (e) => {
    e.preventDefault();
    const loginModal = document.getElementById('login-modal');
    loginModal.innerHTML = `
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Iniciar sesión</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">    

                <form id="js-form">
                        <div class="form-group">
                            <label for="inputEmail">Email address</label>
                            <input id="inputEmail" type="email" class="form-control" aria-describedby="emailHelp">
                        </div>
                        <div class="form-group">
                            <label for="inputPassword">Password</label>
                            <input id="inputPassword" type="password" class="form-control">
                        </div>
                        <button id="log" type="submit" class="btn btn-primary"  >Entrar</button>
                </form>
            
            </div>
        </div>
    </div>
    `
        //console.log(loginModal)
    $(loginModal).modal();

    const formulario = document.getElementById('js-form');
    const email = document.getElementById('inputEmail');
    const password = document.getElementById('inputPassword');

    formulario.addEventListener('submit', async(event) => {
        event.preventDefault();
        const jwt = await postData(email.value, password.value);
        getData2(jwt);
        $(loginModal).modal('hide');

    });
});

//----------------------



const postData = async(email, password) => {
    const urlLog = `${url}api/login`;
    const response = await fetch(urlLog, {
        method: 'Post',
        body: JSON.stringify({ email, password })
    });

    const { token } = await response.json();
    localStorage.setItem("jwt-token", token);
    console.log(token);
    return token;
};

//-----------------------------------------------------------------------------

const getData = (async() => {
    try {
        const response = await fetch(datosUrl);
        const data = await response.json();
        //console.log(data);
        return data;

    } catch (error) {
        return error;
    }

});



const tabla = async() => {
    const { data } = await getData();
    //console.log(data)
    data.forEach(e => {

        document.getElementById('table').innerHTML +=
            `
        <tr>
        <td  >${e.location}</td>
        <td>${e.confirmed}</td>
        <td>${e.deaths}</td>
        <td>${e.recovered}</td>
        <td>${e.active}</td>
        <td><button id="${e.location}" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Ver detalles</button></td>
        </tr>
        
        `
    });



}



tabla();

const grafico = async() => {
    const { data } = await getData();
    const filtrados = data.filter(paises => paises.active >= 10000)

    const paises = []
    const confirmados = []
    const muertes = []
    const recuperados = []
    const activos = []

    filtrados.forEach(e => {
        paises.push(e.location);
        confirmados.push(e.confirmed);
        muertes.push(e.deaths);
        recuperados.push(e.recovered);
        activos.push(e.recovered);
    })

    chart(paises, confirmados, muertes, recuperados, activos);
}

grafico();



const chart = (paises, confirmados, muertes, recuperados, activos) => {
    var ctx = document.getElementById('myChart').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: paises,
            datasets: [{
                    label: 'Casos confirmados',
                    data: confirmados,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)'
                    ],
                    borderWidth: 1

                },
                {
                    label: 'Total muertes',
                    data: muertes,
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.2)'
                    ],
                    borderColor: [
                        'rgba(54, 162, 235, 1)'
                    ],
                    borderWidth: 1

                },
                {
                    label: 'Total recuperados',
                    data: recuperados,
                    backgroundColor: [
                        'rgba(255, 206, 86, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 206, 86, 1)',
                    ],
                    borderWidth: 1

                }, {
                    label: 'Casos activos',
                    data: activos,
                    backgroundColor: [
                        'rgba(75, 192, 192, 0.2)'
                    ],
                    borderColor: [
                        'rgba(75, 192, 192, 1)',
                    ],
                    borderWidth: 1

                }
            ]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}


//---------------------------------------------------------------------------------}}


const graficoModal = (pais) => {
    const { active, confirmed, location, deaths, recovered } = pais
    const ctx = document.getElementById('myChar').getContext('2d');
    const chart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Casos Activos', 'Casos Confirmados', 'Muertos', 'Recuperados'],
            datasets: [{
                label: "Activos",
                data: [active, confirmed, deaths, recovered],
                backgroundColor: [
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                ],
            }],
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: location
                    }
                }
            }
        }
    })
}

const crearModal = async(nombrePais) => {

    try {
        const urlPost = `http://localhost:3000/api/countries/${nombrePais}`
        const response = await fetch(urlPost)

        const { data } = await response.json();
        const modal = document.getElementById('exampleModal');
        modal.innerHTML = `
            <!-- Modal -->
            
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                        </div>
                        <div class="modal-body">
                            <canvas id="myChar" width="400" height="400"></canvas>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
        `
        graficoModal(data);
    } catch (error) {
        console.error(error)
    }
}

table.addEventListener('click', event => {
    crearModal(event.target.id);
});
crearModal();


//---------------------------------------------------------------------------------------------------------------------------

const getData2 = (async(jwt) => {
    try {
        const urlConfirmed = `http://localhost:3000/api/confirmed`
        const responseConfirmed = await fetch(urlConfirmed, {
            method: 'GET',
            headers: {
                Authorization: `Bearer ${jwt}`
            }
        })
        const confirmedData = await responseConfirmed.json();

        const urlDeaths = `http://localhost:3000/api/deaths`
        const responseDeaths = await fetch(urlDeaths, {
            method: 'GET',
            headers: {
                Authorization: `Bearer ${jwt}`
            }
        })
        const deathsData = await responseDeaths.json();

        const urlRecovered = `http://localhost:3000/api/recovered`
        const responseRecovered = await fetch(urlRecovered, {
            method: 'GET',
            headers: {
                Authorization: `Bearer ${jwt}`
            }
        })
        const recoveredData = await responseRecovered.json();

        const confirmados = confirmedData.data
        const muertes = deathsData.data
        const recuperados = recoveredData.data


        graficoChile(confirmados, muertes, recuperados);

    } catch (error) {
        console.error(error);
    }
})



const graficoChile = (confirmed, deaths, recovered) => {

    const fechas = []
    const confirmados = []
    confirmed.forEach(e => {
        fechas.push(e.date)
        confirmados.push(e.total)
    });


    const muertes = []
    deaths.forEach(e => {
        muertes.push(e.total)
    });

    const recuperados = []
    recovered.forEach(e => {
        recuperados.push(e.total)
    });


    const ctx = document.getElementById('myChart2').getContext('2d');
    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: fechas,
            datasets: [{
                    label: "Confirmados",
                    data: confirmados,
                    backgroundColor: [
                        'rgba(75, 192, 192, 0.2)',
                    ],
                    borderColor: [
                        'rgba(75, 192, 192, 1)',
                    ],
                    borderWidth: 1
                },
                {
                    label: "Recuperados",
                    data: recuperados,
                    backgroundColor: [
                        'rgba(153, 102, 255, 0.2)',
                    ],
                    borderColor: [
                        'rgba(153, 102, 255, 1)',
                    ],
                    borderWidth: 1
                },
                {
                    label: "Muertes",
                    data: muertes,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                    ],
                    borderWidth: 1
                },
            ],
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Casos Chile'
                }
            }
        },
    })
}