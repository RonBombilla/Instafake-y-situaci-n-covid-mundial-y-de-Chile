const url = 'http://localhost:3000/';

const formulario = document.getElementById('js-form');
const email = document.getElementById('inputEmail');
const password = document.getElementById('inputPassword');

let contador = 1;

formulario.addEventListener('submit', async(event) => {
    event.preventDefault();
    const jwt = await postData(email.value, password.value);
    await getImg(jwt, contador);
    logoutBtn();
    formulario.style.display = 'none';
});

const postData = async(email, password) => {
    const urlLog = `${url}api/login`;
    const response = await fetch(urlLog, {
        method: 'Post',
        body: JSON.stringify({ email, password })
    });

    const { token } = await response.json();
    localStorage.setItem("jwt-token", token);
    console.log(token);
    return token;
};

const getImg = async(jwt, num = 1) => {
    try {
        const urlImg = `${url}api/photos?page=${num}`;
        const response = await fetch(urlImg, {
            method: 'GET',
            headers: {
                Authorization: `Bearer ${jwt}`
            }

        });

        const { data } = await response.json();
        hideSection(formulario);
        createTable(data);
        createBtnShowMore();
        contador++;

    } catch (error) {
        localStorage.clear();
        console.log(error)
    }
}


const hideSection = (section) => {
    const hide = section;
    if (hide.style.display == "none") {
        hide.style.display = 'block'
    } else {
        hide.style.display = "none"
    }
}

const createTable = (data) => {
    const divTable = document.getElementById('js-table-wrapper')
    divTable.style.display = 'block'
    const table = document.getElementById('table-photos').getElementsByTagName('tbody')[0]
    data.forEach(e => {
        table.innerHTML += /*HTML */
            `
            <tr>
            <td>${e.author}</td>
            <td><img src="${e.download_url}" class="img-fluid"></td>
          </tr>
            `
    })
}

const createBtnShowMore = () => {
    const btnMostrar = document.getElementById('btn-mostrar')
    btnMostrar.innerHTML = ""
    btnMostrar.innerHTML += /*HTML*/
        `
        <div class="row text-center ml-5 mb-4" style="display:block">
            <button id="mostrarMas" type="button" class="btn btn-primary">Mostrar más</button>
        </div>
    
    `
    const btnMostrarMas = document.getElementById('mostrarMas');
    const jwt = localStorage.getItem('jwt-token')
    btnMostrarMas.addEventListener('click', (e) => {
        e.preventDefault();
        formulario.innerHTML = ''
        getImg(jwt, contador)
    })
}

const logoutBtn = () => {

    const boton = document.getElementById('out')
        //formulario.innerHTML = ''
    boton.innerHTML = `<button id="logout" type="button" class="btn btn-danger">Cerrar Sesión</button>`

    boton.style.display = 'block'
    const logout = document.getElementById('logout');
    const divTable = document.getElementById('js-table-wrapper')
    const btnMostrar = document.getElementById('btn-mostrar')
        //const btnMostrarMas = document.getElementById('mostrarMas');
    logout.addEventListener('click', e => {
        e.preventDefault();
        hideSection(btnMostrar)
        hideSection(divTable)
        hideSection(boton)
        localStorage.clear();
        window.location.reload();
    })

};



/*
const pagination = document.getElementById('paginas');
const bla = pagination.addEventListener('click', (event) => {
    event.preventDefault();
    const atras = document.getElementById('atras');
    const siguiente = document.getElementById('siguiente');
    const valor = 1;

    if (atras) {
        return --valor;
    } else if (siguiente) {
        return ++valor;
    }
});
*/